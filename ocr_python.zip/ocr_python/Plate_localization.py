##########################################################################
#                                                                        #
# Plate_localization.py                                                            #
# Owner: Infopulse LLC.                                                  #
# Designed by: Andrii Karpovych                                          #
# Created by: Andrii Karpovych                                           #
# Date Released: 2019-09-01                                              #
# Application: Car Plates recognition (Ukraine Plates Optimized)         #
#                                                                        #
##########################################################################
import cv2
import numpy as np
import PossiblePlate
import math
import Char_Recognition

# module level variables ##########################################################################
PLATE_WIDTH_PADDING_FACTOR = 1.3
PLATE_HEIGHT_PADDING_FACTOR = 1.5
SCALAR_WHITE = (255,0,0)

def Localize_Plate_In_Scene (ImCapture, plate_cascade):
    # Resize image
    Im_gray = cv2.cvtColor(ImCapture, cv2.COLOR_BGR2GRAY)
    plates = plate_cascade.detectMultiScale(Im_gray, 1.3, 10)
    plate = np.amax(plates, axis=0)
    cv2.rectangle(ImCapture, (int(plate[0]),int(plate[1])), (int(plate[0]+plate[2]), int(plate[1]+plate[3])), SCALAR_WHITE, 2)

    intX = int(plate[0])
    intY = int(plate[1])
    intW = int(plate[2])
    intH = int(plate[3])

    intCenterX = int((intX + intX + intW) / 2)
    intCenterY = int((intY + intY + intH) / 2)
    ptPlateCenter = intCenterX, intCenterY

    plate_crop_img = cv2.getRectSubPix(ImCapture, (intW, intH), tuple(ptPlateCenter))

    img_plate_colour = cv2.cvtColor(plate_crop_img, cv2.COLOR_BGR2RGB)
    img_plate_gray = cv2.cvtColor(img_plate_colour, cv2.COLOR_BGR2GRAY)
    ret, Im_Croped_thresh = cv2.threshold(img_plate_gray, 110, 255, 0)

    return plate_crop_img


###################################################################################################
def extractPlate(imgOriginal, listOfMatchingChars):
    possiblePlate = PossiblePlate.PossiblePlate()           # this will be the return value

    listOfMatchingChars.sort(key = lambda matchingChar: matchingChar.intCenterX)        # sort chars from left to right based on x position

            # calculate the center point of the plate
    fltPlateCenterX = (listOfMatchingChars[0].intCenterX + listOfMatchingChars[len(listOfMatchingChars) - 1].intCenterX) / 2.0
    fltPlateCenterY = (listOfMatchingChars[0].intCenterY + listOfMatchingChars[len(listOfMatchingChars) - 1].intCenterY) / 2.0

    ptPlateCenter = fltPlateCenterX, fltPlateCenterY

            # calculate plate width and height
    intPlateWidth = int((listOfMatchingChars[len(listOfMatchingChars) - 1].intBoundingRectX + listOfMatchingChars[len(listOfMatchingChars) - 1].intBoundingRectWidth - listOfMatchingChars[0].intBoundingRectX) * PLATE_WIDTH_PADDING_FACTOR)

    intTotalOfCharHeights = 0

    for matchingChar in listOfMatchingChars:
        intTotalOfCharHeights = intTotalOfCharHeights + matchingChar.intBoundingRectHeight
    # end for

    fltAverageCharHeight = intTotalOfCharHeights / len(listOfMatchingChars)

    intPlateHeight = int(fltAverageCharHeight * PLATE_HEIGHT_PADDING_FACTOR)

            # calculate correction angle of plate region
    fltOpposite = listOfMatchingChars[len(listOfMatchingChars) - 1].intCenterY - listOfMatchingChars[0].intCenterY
    fltHypotenuse = Char_Recognition.distanceBetweenChars(listOfMatchingChars[0], listOfMatchingChars[len(listOfMatchingChars) - 1])
    fltCorrectionAngleInRad = math.asin(fltOpposite / fltHypotenuse)
    fltCorrectionAngleInDeg = fltCorrectionAngleInRad * (180.0 / math.pi)

            # pack plate region center point, width and height, and correction angle into rotated rect member variable of plate
    possiblePlate.rrLocationOfPlateInScene = (tuple(ptPlateCenter), (intPlateWidth, intPlateHeight), fltCorrectionAngleInDeg )

            # final steps are to perform the actual rotation
            # get the rotation matrix for our calculated correction angle
    rotationMatrix = cv2.getRotationMatrix2D(tuple(ptPlateCenter), fltCorrectionAngleInDeg, 1.0)

    height, width, numChannels = imgOriginal.shape      # unpack original image width and height
    imgRotated = cv2.warpAffine(imgOriginal, rotationMatrix, (width, height))       # rotate the entire image
    imgCropped = cv2.getRectSubPix(imgRotated, (intPlateWidth, intPlateHeight), tuple(ptPlateCenter))
    possiblePlate.imgPlate = imgCropped         # copy the cropped plate image into the applicable member variable of the possible plate
    return possiblePlate
# end function