##########################################################################
#                                                                        #
# Mainproc.py                                                            #
# Owner: Infopulse LLC.                                                  #
# Designed by: Andrii Karpovych                                          #
# Created by: Andrii Karpovych                                           #
# Date Released: 2019-09-16                                              #
# Application: Car Plates recognition (Ukrainian Plates Optimized)       #
##########################################################################

import numpy as np
import cv2
import os
import time
import sys
import socket
import Preprocess
import Char_Recognition
import Plate_localization
import Data_from_DB
import Camera_Stream
import logging
from threading import Thread
from threading import Event
from itertools import chain


enter_link = 'rtsp://prog:nmt88Ucv@172.27.60.91:554/Streaming/Channels/103'      # Camera channel
exit_link = 'rtsp://prog:nmt88Ucv@172.27.60.92:554/Streaming/Channels/103'      # Camera channel
magic = [0x23]
enter = [0x4E]
exit = [0x58]
carriage_return = [0x0D]
line_feed = [0x0A]

showSteps = False

FILENAME = f'/var/log/ocr_log.log'
logging.basicConfig(filename=FILENAME, level=logging.INFO)

#In case of defining this global variable to 'TRUE', comment loop of video capture!!!
logging.info(f"Program starts at {time.ctime()}")

# Trying to load pre-trained 'Haar Classifier' for Plates Localization within scene
try:
    plate_cascade = cv2.CascadeClassifier('plate_cascade.xml')                # read in the pre-trained classifier
except:  # if file could not be opened
    logging.error("error, unable to open 'plate_cascade.xml', exiting program\n")     # show error message
    os.system("pause")
    # End try

# Trying to load flatten images for cv2 KNN training
try:
    npaFlattenedImages = np.loadtxt("flimages", np.float32)
except OSError:
    print("error, unable to open 'flattened_images.txt', exiting program\n")  # show error message
    os.system("pause")
    # End try

# Trying to load labels for flatten images (KNN training)
try:
    npaClassifications = np.loadtxt("classifications.txt", np.float32)
except OSError:
    logging.error("error, unable to open 'classifications.txt', exiting program\n")  # show error message
    os.system("pause")
    #End try

# Trying to get KNN object
KNNTrained = []
try:
    KNNTrained = Char_Recognition.functionKNNtrain(npaFlattenedImages, npaClassifications)  # attempt KNN training
except NameError:
    logging.error("npaFlattenedImages' file is not available!\n")
    os.system("pause")
        # End try
# Getting list of allowed plate numbers to get access to internal parking lot
allowedNumbers = Data_from_DB.Data_from_DB().plate_Numbers_Allowed
event = Event() #Creating the Event instance to interact between Threads

# Method get_Card_ID returns byte string relevant to recognized plate number to propagate to the security system
def get_card_ID(Plate_Namber_Straing):
    position = np.where(allowedNumbers[:,0] == Plate_Namber_Straing)
    position = position[0][0]
    card_str = allowedNumbers[position, 1:].reshape(-1)
    card_bytes = np.fromiter((int(x, 16) for x in card_str), dtype=np.uint32)
    return card_bytes

#Main lodic module
def processor(process_name, device, socket_connection, sock_host, sock_port):

    cap = Camera_Stream.Camera_Stream(device)
    logging.info(f'Initializing the Stream: {process_name}..')
    time.sleep(1)  # warming up the Camera matrix
    # Start attempting to read if it is opened
    while cap.is_active():
            imOriginal = cap.get_Frame()
            # Only display the image if it is not empty
            if np.shape(imOriginal) != ():
                #imOriginal_res = cv2.resize(imOriginal, (640, 480))
                #cv2.imshow(f"video output {process_name}", imOriginal_res)
                im_Croped_Plate = []
                try:
                    im_Croped_Plate = Plate_localization.Localize_Plate_In_Scene(imOriginal, plate_cascade)
                except:
                    #print(f"Capturing from video input stream: {process_name} ")
                    continue
                if (len(im_Croped_Plate) > 0):
                    #if showSteps == True:
                     #   cv2.imshow("Cropped Plate color", im_Croped_Plate)
                    imgGrayscale, ImThresh = Preprocess.preprocess(im_Croped_Plate)
                    #if showSteps == True:
                    #    cv2.imshow("ImThresh", ImThresh)

                    listOfPossiblePlates = Char_Recognition.findCharsInLocalizedPlate(ImThresh, im_Croped_Plate)

                    if len(listOfPossiblePlates) > 0:
                        plateNumberString = Char_Recognition.detectMatchingCarsInPlate(listOfPossiblePlates, KNNTrained)
                        logging.info(f'{time.ctime()}Plate number has been detected on {process_name}: {str(plateNumberString)}')
                        if plateNumberString in allowedNumbers[:,0]:
                            logging.info('allowed...') #del
                            card_ID = get_card_ID(plateNumberString)
                            if not event.is_set():
                                #logging.info('seting the event') #del
                                if process_name == 'ENTER':
                                    signal_seq = chain(magic, card_ID , enter, carriage_return, line_feed)
                                else:
                                    signal_seq = chain(magic, card_ID, exit, carriage_return, line_feed)
                                try:
                                    socket_connection.send(bytes("".join(map(chr, signal_seq)), encoding='utf-8'))
                                except:
                                    # recreate the socket and reconnect
                                    socket_connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                                    socket_connection.connect((sock_host, sock_port))
                                    socket_connection.send(bytes("".join(map(chr, signal_seq)), encoding='utf-8'))
                                logging.info(f'Opening gate for: {str(plateNumberString)}')  # Open device
                                event.set()
                                #print("status event: ", event.is_set())
                                time.sleep(10)  # waiting for gate closing...
                                event.clear()
                            else:
                                    #logging.info(f"{process_name} is sleeping on Event from back direction camera")
                                    time.sleep(10)
                        else:
                            continue  # Plate number has been recognized but not in the allowed list to pass through the gate
                    else:
                        continue  # print('Error: no plates were recognized!\n')
            else:
                del cap
                logging.error(f"Error reading capture device {device}")
                logging.info(f"Reinitialize capture device {time.ctime()}")
                cap = Camera_Stream.Camera_Stream(device)
                time.sleep(1)  # warming up the Camera matrix

    logging.info('Exit Program')
    socket_connection.close()
    sys.exit(0)


#############################################___MAIN___#######################################################

def main():
    global socket_connection
    sock_host = '172.27.60.101'
    sock_port = 9761
    # Trying to establish connection with opening-gate module
    try:
        # create an TCP socket 'AF_INET', STREAMing socket
        socket_connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        socket_connection.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        # connect to the web server on port 9761 - COM port
        socket_connection.connect((sock_host, sock_port))

    except TimeoutError:
        logging.error(
            "A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond\n")  # show error message
        os.system("pause")
        # End try

    ENTER = Thread(target=processor, args=("ENTER", enter_link, socket_connection, sock_host, sock_port))
    EXIT = Thread(target=processor, args=("EXIT", exit_link, socket_connection, sock_host, sock_port))

    ENTER.start()
    EXIT.start()

if __name__ == "__main__":
    main()

#r = requests.get(url=URL, params=trigger_param)

#print(r.text)
