##########################################################################
#                                                                        #
# Mainproc.py                                                            #
# Owner: Infopulse LLC.                                                  #
# Designed by: Andrii Karpovych                                          #
# Created by: Andrii Karpovych                                           #
# Date Released: 2019-09-16                                              #
# Application: Car Plates recognition (Ukrainian Plates Optimized)       #
##########################################################################

import numpy as np
import cv2
import os
import time
import sys
import Preprocess
import Char_Recognition
import Plate_localization
import Camera_Stream
import Allowed_Numbers
import requests
import tracemalloc
import memory_trace

device = 'rtsp://prog:nmt88Ucv@172.27.60.92:554/Streaming/Channels/103'      # Camera channel
#device = str(sys.argv[1])
URL = 'http://admin:vkmodule@172.27.60.100/protect/leds.cgi'                 # Gate trigger URL
trigger_param = (('led', '0'), ('timeout', '2'))                             # Gate trigger parameters
showSteps = False                                                            #In case of defining this global variable to 'TRUE', comment loop of video capture!!!
print("Program starts at ", time.ctime())

# Trying to load pre-trained 'Haar Classifier' for Plates Localization within scene
try:
    plate_cascade = cv2.CascadeClassifier('plate_cascade.xml')                # read in the pre-trained classifier
except:  # if file could not be opened
    print("error, unable to open 'plate_cascade.xml', exiting program\n")     # show error message
    os.system("pause")
    # End try

# Trying to load flatten images for cv2 KNN training
try:
    npaFlattenedImages = np.loadtxt("flattened_images.txt", np.float32)
except OSError:
    print("error, unable to open 'flattened_images.txt', exiting program\n")  # show error message
    os.system("pause")
    # End try

# Trying to load labels for flatten images (KNN training)
try:
    npaClassifications = np.loadtxt("classifications.txt", np.float32)
except OSError:
    print("error, unable to open 'classifications.txt', exiting program\n")  # show error message
    os.system("pause")
    #End try


#############################################___MAIN___#######################################################

# Trying to get KNN object
KNNTrained = []
try:
    KNNTrained = Char_Recognition.functionKNNtrain(npaFlattenedImages, npaClassifications)  # attempt KNN training
except NameError:
    print("npaFlattenedImages' file is not available!\n")
    os.system("pause")
        # End try

# Getting list of allowed plate numbers to get access to internal parking lot
allowedNumbers = Allowed_Numbers.Allowed_Numbers()
#tracing:


cap = Camera_Stream.Camera_Stream(device)
print('Initializing the Camera...')
time.sleep(2)                                                            #  warming up the Camera matrix
# Start attempting to read if it is opened
while cap.is_active():
        tracemalloc.start()
        imOriginal = cap.get_Frame()
        # Only display the image if it is not empty
        if np.shape(imOriginal) != ():
            imOriginal_res = cv2.resize(imOriginal, (640, 480))
            cv2.imshow("video output", imOriginal_res)
            im_Croped_Plate = []
            try:
                im_Croped_Plate = Plate_localization.Localize_Plate_In_Scene(imOriginal, plate_cascade)
            except:
                print("Capturing from video input.. ")
            if (len(im_Croped_Plate) > 0):
                if showSteps == True:
                    cv2.imshow("Cropped Plate color", im_Croped_Plate)
                imgGrayscale, ImThresh = Preprocess.preprocess(im_Croped_Plate)
                if showSteps == True:
                    cv2.imshow("ImThresh", ImThresh)

                listOfPossiblePlates = Char_Recognition.findCharsInLocalizedPlate(ImThresh, im_Croped_Plate)

                if len(listOfPossiblePlates) > 0:
                    plateNumberString = Char_Recognition.detectMatchingCarsInPlate(listOfPossiblePlates, KNNTrained)
                    print('Plate number has been detected: ', str(plateNumberString))
                    isAllowed = allowedNumbers.compare(plateNumberString)
                    if isAllowed == True:
                        print('Opening gate for: ', str(plateNumberString))           #Open device
                        r = requests.get(url=URL, params=trigger_param)
                        print(r.text)
                        time.sleep(5)                                      # waiting for gate closing...
                    else:
                        continue  #Plate number has been recognized but not in the allowed list to pass through the gate
                else:
                    continue  # print('Error: no plates were recognized!\n')
        else:
            snapshot = tracemalloc.take_snapshot()
            memory_trace.display_top(snapshot)
            del cap
            print("Error reading capture device")
            print("Reinitialize capture device ", time.ctime())
            cap = Camera_Stream.Camera_Stream(device)
            time.sleep(2)                                                 #  warming up the Camera matrix
        k = cv2.waitKey(30) & 0xFF
        if k == 27:
            del cap
            snapshot = tracemalloc.take_snapshot()
            memory_trace.display_top(snapshot)
            #cap.thread_kill()
            cv2.destroyAllWindows()
            print('Exit')
            break
        if k == 73:
            snapshot = tracemalloc.take_snapshot()
            memory_trace.display_top(snapshot)
            continue
#r = requests.get(url=URL, params=trigger_param)

#print(r.text)