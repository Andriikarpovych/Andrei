##########################################################################
#                                                                        #
# Camera_Stream.py                                                       #
# Owner: Infopulse LLC.                                                  #
# Designed by: Andrii Karpovych                                          #
# Created by: Andrii Karpovych                                           #
# Date Released: 2019-09-12                                              #
# Application: Car Plates recognition (Ukrainian Plates Optimized)       #
##########################################################################

import threading
from threading import Lock
import cv2
import sys


# class Camera_Stream #################################################################################
# Intended to manage RTSP Stream buffer using multi threading and allways taking the last frame from the RTSP.
# Class Camera_Stream implemented as LIFO stack


class Camera_Stream:
    last_frame = None
    last_ready = None
    lock = Lock()
    capture = None

    ###############################__Constructor__#####################################################
    def __init__(self, rtsp_link):
        self.capture = cv2.VideoCapture(rtsp_link)
        thread = threading.Thread(target=self.rtsp_buffer, args=(self.capture,), name="rtsp_read_thread")
        thread.daemon = False
        thread.start()
        # end method

    ###################################################################################################
    def rtsp_buffer(self, capture):
        while True:
            #with self.lock:
                self.last_ready, self.last_frame = capture.read()
    # end method

    ###################################################################################################
    def get_Frame(self):
        if self.last_frame is not None:
            return self.last_frame.copy()
        else:
            return None
    # end method

    ###################################################################################################
    def is_active(self):
        if self.capture.isOpened():
            return True
        else: return False
# end class