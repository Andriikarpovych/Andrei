import numpy as np
import os
import pyodbc

server = 'al-sqlinst6.infopulse.local,1453'
database = 'CorporateDWH'
username = 'Parking.Datareader'
password = '2bx65V3hAf'
cnxn = pyodbc.connect(
'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
cursor = cnxn.cursor()
cursor.execute(
                "SELECT [License_Plate],[b1n1],[b1n2],[b2n1],[b2n2],[b3n1],[b3n2],[b4n1],[b4n2],[b5n1],[b5n2] FROM [CorporateDWH].[dbo].[ParkingPlaces]")
plate_Numbers_Allowed = np.array(cursor.fetchall(), dtype=str)
print(plate_Numbers_Allowed)

