import sys
import socket
import numpy as np
import pandas as pd
#enter_arg = sys.argv[1]
#device = sys.argv[2]
#print("args: ", enter_arg)
#print("args: ", device)
from itertools import chain
# create an TCP socket 'AF_INET', STREAMing socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#connect to the web server on port 9761 - COM port
s.connect(("172.27.60.101", 9761))
magic = [0x23]
enter = [0x4E]
exit = [0x58]
carriage_return = [0x0D]
line_feed = [0x0A]
plateNumberString = 'BH2855CT'
allowed_numbers  = np.genfromtxt("./Internal_Plates_Number.csv", delimiter=',', dtype='str')
position = np.where(allowed_numbers[:, 0] == plateNumberString)
position = position[0][0]
hex_str = allowed_numbers[position, 1:].reshape(-1)
x = np.fromiter( (int(x, 16) for x in hex_str), dtype=np.uint32)
signal_seq = chain(magic, x, exit, carriage_return, line_feed)
s.send(bytes("".join(map(chr, signal_seq)), encoding='utf-8'))
#print(bytes("".join(map(chr, signal_seq)), encoding='utf-8'))
s.close()
