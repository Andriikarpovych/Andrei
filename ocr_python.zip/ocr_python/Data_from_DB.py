##########################################################################
#                                                                        #
# Data_from_DB.py                                                            #
# Owner: Infopulse LLC.                                                  #
# Designed by: Andrii Karpovych                                          #
# Created by: Andrii Karpovych                                           #
# Date Released: 2019-09-16                                              #
# Application: Car Plates recognition (Ukrainian Plates Optimized)       #
##################################################################
#use the following commands to install ODBC driver before pyodbc
# sudo apt-get install build-essential libssl-dev libffi-dev python3-dev
# sudo apt-get install unixodbc-dev
import numpy as np
import os
import pyodbc

class Data_from_DB():

    def __init__(self):

        # Some otherexample server values are
        # server = 'localhost\sqlexpress' # for a named instance
        # server = 'myserver,port' # to specify an alternate port
        # server = 'tcp:myserver.database.windows.net'
#        self.server = '172.27.145.41,1433'
        self.server = 'al-sqlinst6.infopulse.local,1453'
        self.database = 'CorporateDWH'
        self.username = 'Parking.Datareader'
        self.password = '2bx65V3hAf'
        try:
            cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+self.server+';DATABASE='+self.database+';UID='+self.username+';PWD='+ self.password)
            cursor = cnxn.cursor()
            cursor.execute("SELECT [License_Plate],[b1n1],[b1n2],[b2n1],[b2n2],[b3n1],[b3n2],[b4n1],[b4n2],[b5n1],[b5n2] FROM [CorporateDWH].[dbo].[ParkingPlaces]")
            self.plate_Numbers_Allowed = np.array(cursor.fetchall(),dtype=str)
        except pyodbc.OperationalError:
            print("Login timeout expired (0) (SQLDriverConnect)'\n")
            os.system("pause")
        except pyodbc.InterfaceError:
            print(f'Login failed for user {self.username}')
            os.system("pause")
