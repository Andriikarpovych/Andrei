##########################################################################
#                                                                        #
# Allowed_Numbers.py                                                            #
# Owner: Infopulse LLC.                                                  #
# Designed by: Andrii Karpovych                                          #
# Created by: Andrii Karpovych                                           #
# Date Released: 2019-09-16                                              #
# Application: Car Plates recognition (Ukrainian Plates Optimized)       #
##########################################################################

import numpy as np
import os


class Allowed_Numbers():

    # constructor #################################################################################
    def __init__(self):
            # Trying to get Infopulse allowed plate numbers from text file
        try:
            self.allowed_numbers = np.loadtxt("./Plate_Numbers_Allowed/Internal_Plates_Number.txt", dtype='str', delimiter="\n",) # attempt KNN training
            np.sort(self.allowed_numbers, axis=0)
        except NameError:
            print("Internal_Plates_Number.txt' file is not available!\n")
            os.system("pause")
            # End try


    #end constructor

    #comparator #################################################################################
    def compare(self, plateNumberString):
        if plateNumberString in self.allowed_numbers:
            return True
        else:
            return False
# end class

